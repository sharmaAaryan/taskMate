import { Link } from "react-router-dom";
import "../App.css";

function Navbar() {
  return (
    <header className="navbar">
      <div className="logo">TaskMate</div>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/browse">Browse Tasks</Link>
        <Link to="/login">Login</Link>
        <Link to="/register">
          <button className="register-btn">Register</button>
        </Link>
      </nav>
    </header>
  );
}

export default Navbar;