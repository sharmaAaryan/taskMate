function BrowseTasks() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Browse Tasks</h2>
      <p>Here users can explore available tasks.</p>
    </div>
  );
}

export default BrowseTasks;