function Register() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Register</h2>
      <p>Registration form will be here.</p>
    </div>
  );
}

export default Register;