function Login() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Login</h2>
      <p>Login form will be here.</p>
    </div>
  );
}

export default Login;