import { Routes, Route, Link } from "react-router-dom";
import "./App.css";

/* Home Page */
function Home() {
  return (
    <>
      <section className="hero">
        <h1>
          Get help. <span>Give help.</span> Get paid.
        </h1>
        <p>
          TaskMate connects people who need help with assignments and projects
          to skilled volunteers — ethically, transparently, and on time.
        </p>

        <div className="buttons">
          <button className="primary">I Need Help</button>
          <button className="secondary">I Want to Help</button>
        </div>
      </section>

      <section className="how">
        <h2>How TaskMate Works</h2>

        <div className="cards">
          <div className="card">
            <h3>1. Post Your Task</h3>
            <p>Upload your assignment and set a deadline.</p>
          </div>

          <div className="card">
            <h3>2. Get Matched</h3>
            <p>Volunteers review your task and offer help.</p>
          </div>

          <div className="card">
            <h3>3. Learn & Complete</h3>
            <p>Receive ethical help and finish on time.</p>
          </div>
        </div>
      </section>
    </>
  );
}

/* Other Pages */
function BrowseTasks() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Browse Tasks</h2>
      <p>Here users can explore available tasks.</p>
    </div>
  );
}

function Login() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Login</h2>
      <p>Login form will be here.</p>
    </div>
  );
}

function Register() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Register</h2>
      <p>Registration form will be here.</p>
    </div>
  );
}

/* Main App */
function App() {
  return (
    <>
      {/* Navbar */}
      <header className="navbar">
        <div className="logo">TaskMate</div>
        <nav>
          <Link to="/">Home</Link>
          <Link to="/browse">Browse Tasks</Link>
          <Link to="/login">Login</Link>
          <Link to="/register">
            <button className="register-btn">Register</button>
          </Link>
        </nav>
      </header>

      {/* Routes */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/browse" element={<BrowseTasks />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </>
  );
}

export default App;